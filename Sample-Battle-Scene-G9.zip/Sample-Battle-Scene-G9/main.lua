-- Sample-Battle-Scene-G9 -- fork of Sample-Battle-Scene, retargeted at
-- g9-Battle-Scene instead of g2-Battle-Scene. Exists for one reason:
-- g9-Battle-Scene has no consumer of its own -- nothing anywhere else in
-- this workspace calls its mod.exports.pushLayoutBattle -- so the whole
-- g9-battle-engine-beta connection (turn resolution via
-- resolveTurnActions, native EXP/catch, the battle-exit music sequence)
-- has never had a real, live encounter to run through. This is that
-- encounter. Same TEST/EXAMPLE status as the mod it forks from -- either
-- delete it once the connection's been exercised, or keep it installed as
-- a working reference.
--
-- Do NOT enable alongside Sample-Battle-Scene: both mods independently
-- wrap World.tryWildEncounter, and two mods intercepting the same
-- encounter conflicts. Pick one.
--
-- Deliberately simplified vs g2-Battle-Scene's own world_intercept.lua
-- (deleted from that mod entirely, per this session's earlier decision --
-- see g2-Battle-Scene's own manifest.json): extra enemy slots (beyond the
-- one real wild roll the native trigger already committed to) clone that
-- roll's own species/level rather than rolling distinct wild mons per
-- slot, and a missing ally slot is just left out rather than a fresh mon
-- being created and appended to the real save party.
--
-- Trap technique (temporarily swap World.startBattle, call the
-- unmodified original tryWildEncounter, restore, act on what got
-- captured) is unchanged from Sample-Battle-Scene's own -- confirmed the
-- only clean way to intercept a wild encounter in this engine.
--
-- NOT carried over from Sample-Battle-Scene: the g2-Battle-Scene custom
-- E-menu button listener (mod.events:on("mod.g2-Battle-Scene.customButton",
-- ...)) -- that's g2-Battle-Scene's own comms channel specifically, not
-- something g9-Battle-Scene emits.
--
-- Added since: wild_forms's Eternatus-as-Eternamax static (INDIGO_PLATEAU,
-- level 75) now routes through g9-Battle-Scene's own "bossFight" layout
-- instead of the ordinary battle screen -- explicit user request. A
-- SEPARATE, PERMANENT World:startBattle wrap, not the scoped
-- tryWildEncounter trap below -- that fight is object_event-triggered, a
-- different call path the scoped trap never sees. See that wrap's own
-- header for the full grounding.
--
-- Also added: an ordinary wild encounter is a fixed 25% chance of the
-- "doubles" layout instead of the ordinary single "wildEncounter" one,
-- and EVERY trainer battle routes to "doubles" whenever that trainer
-- actually has 2+ Pokemon (tryDoublesTrainer, in the same permanent wrap
-- as Eternatus, for the same reason -- a trainer battle is script-VM
-- triggered, not tryWildEncounter). Both explicit user requests.
return function(mod)
  local World = require("src.world.gen2.World")
  local Mon = require("src.battle.gen2.Mon")

  -- Eternatus-as-Eternamax -> g9-Battle-Scene's "bossFight" layout,
  -- explicit user request. This static placement (wild_forms's own
  -- data/legendaries.lua -- INDIGO_PLATEAU, level 75, form =
  -- "ETERNATUS_ETERNAMAX") is confirmed Gen-1-only (wild_forms/main.lua's
  -- own `if gen2 then [warn, no Gen 2 static placement] else
  -- legendaries.place(...) end` branch) and, more importantly for THIS
  -- trap, is triggered by an object_event -- an entirely different call
  -- path than the grass/water roll tryWildEncounter below intercepts, so
  -- the existing trap never sees it at all. A PERMANENT wrap here, not a
  -- scoped one, is what's needed to catch it too.
  --
  -- The object_event's own `pokemon` field is confirmed the BARE
  -- "ETERNATUS" id, never the form-suffixed one (data/legendaries.lua's
  -- own header: "never the form-suffixed id -- because a player never
  -- keeps Eternamax") -- wild_forms's own battle.started listener is what
  -- applies ETERNATUS_ETERNAMAX onto the live battler, AFTER
  -- World:startBattle constructs the real Battle.new (Runtime.emit
  -- "battle.started" fires unconditionally from inside that constructor,
  -- confirmed real and generation-agnostic) -- so this trap only ever
  -- needs to recognize the species+level signature at opts.wild, matching
  -- the placement's own data, and wild_forms's own form-swap keeps working
  -- completely unmodified regardless of which layout renders the fight.
  -- Every trainer battle -> g9-Battle-Scene's "doubles" layout, whenever
  -- the trainer actually has 2+ Pokemon -- explicit user request ("make
  -- all trainer battles be double battles if possible"). Same permanent-
  -- wrap reasoning as Eternatus above: a trainer battle is triggered by
  -- the script VM (dialogue/approach), never tryWildEncounter, so only a
  -- permanent World:startBattle wrap sees it. The REAL trainer table
  -- (opts.trainer -- class/name/baseMoney/party, the same shape
  -- World:startBattle itself always builds one from) is forwarded
  -- through unmodified so the payout/gym-leader-happiness/name all stay
  -- correct -- see buildBattle's own fix in g9-Battle-Scene/battle_screen
  -- .lua for why a plain boolean flag would have silently zeroed the
  -- payout.
  local function tryDoublesTrainer(self, opts)
    if not (opts and opts.trainer and type(opts.trainer.party) == "table"
        and #opts.trainer.party >= 2) then
      return false
    end
    local exportMod = mod.find("g9-Battle-Scene")
    local save = self.game and self.game.save
    if not (exportMod and exportMod.exports and exportMod.exports.pushLayoutBattle
        and save and save.party) then
      return false
    end
    local layoutData = exportMod.exports.getLayoutData
      and exportMod.exports.getLayoutData("doubles")
    local enemyCount = math.max(1, math.min(6, (layoutData and layoutData.enemyCount) or 2))
    local allyCount = math.max(1, math.min(6, (layoutData and layoutData.allyCount) or 2))
    local enemies = {}
    for i = 1, math.min(enemyCount, #opts.trainer.party) do
      enemies[#enemies + 1] = opts.trainer.party[i]
    end
    if #enemies < 2 then return false end
    local players = {}
    for i = 1, allyCount do
      if save.party[i] then players[#players + 1] = save.party[i] end
    end
    local pushed = exportMod.exports.pushLayoutBattle("doubles", self.game, self, {
      enemies = enemies,
      players = players,
      trainer = opts.trainer,
    })
    if not pushed then
      mod.log:warn("Sample_Battle_Scene_G9: no doubles preset on the export "
        .. "mod, falling back to the ordinary trainer battle")
      return false
    end
    return true
  end

  local nativeStartBattle = World.startBattle
  function World:startBattle(opts, onDone)
    if opts and opts.wild and opts.wild.species == "ETERNATUS"
        and opts.wild.level == 75
        and not opts.roaming and not opts.contest and not opts.tutorial then
      local exportMod = mod.find("g9-Battle-Scene")
      local save = self.game and self.game.save
      if exportMod and exportMod.exports and exportMod.exports.pushLayoutBattle
          and save and save.party then
        local layoutData = exportMod.exports.getLayoutData
          and exportMod.exports.getLayoutData("bossFight")
        local allyCount = math.max(1, math.min(6, (layoutData and layoutData.allyCount) or 4))
        local players = {}
        for i = 1, allyCount do
          if save.party[i] then players[#players + 1] = save.party[i] end
        end
        local pushed = exportMod.exports.pushLayoutBattle("bossFight", self.game, self, {
          enemies = { opts.wild },
          players = players,
        })
        if pushed then return true end
        mod.log:warn("Sample_Battle_Scene_G9: no bossFight preset on the export "
          .. "mod, falling back to the ordinary battle screen for Eternatus")
      end
    elseif tryDoublesTrainer(self, opts) then
      return true
    end
    return nativeStartBattle(self, opts, onDone)
  end

  -- realStartBattle is THIS mod's own wrapped startBattle above, not the
  -- raw native one -- so an ordinary wild roll still round-trips through
  -- the Eternatus check too on its way to native (a harmless no-op for
  -- anything that isn't that exact species+level) once tryWildEncounter's
  -- own temporary override below restores it.
  local realStartBattle = World.startBattle
  local originalTryWildEncounter = World.tryWildEncounter

  function World:tryWildEncounter()
    local save = self.game and self.game.save
    if not (save and save.party and #save.party >= 2) then
      return originalTryWildEncounter(self)
    end

    local capturedOpts = nil
    World.startBattle = function(selfInner, opts, onDone)
      if opts and opts.wild and not opts.roaming and not opts.contest and not opts.tutorial then
        capturedOpts = opts
        return true
      end
      return realStartBattle(selfInner, opts, onDone)
    end

    local ok, triggered = pcall(originalTryWildEncounter, self)
    World.startBattle = realStartBattle

    if not ok then
      mod.log:warn("Sample_Battle_Scene_G9: tryWildEncounter errored: %s", tostring(triggered))
      return false
    end
    if not (triggered and capturedOpts) then
      return triggered
    end

    -- mod.find, not a direct require -- the sanctioned way to reach
    -- another mod's own exports table (nil if that mod is absent,
    -- disabled, or hasn't run yet).
    local exportMod = mod.find("g9-Battle-Scene")
    if not (exportMod and exportMod.exports and exportMod.exports.pushLayoutBattle) then
      mod.log:warn("Sample_Battle_Scene_G9: g9-Battle-Scene not available, "
        .. "falling back to a single wild battle")
      realStartBattle(self, capturedOpts)
      return true
    end

    -- 25% fixed chance of the "doubles" layout instead of the ordinary
    -- single "wildEncounter" -- explicit user request. The second doubles
    -- slot clones the one real wild roll's own species/level, same
    -- documented simplification this file's own header already states
    -- for any enemyCount > 1 (this engine's own tryWildEncounter commits
    -- to exactly one real roll; there is no second, independent roll to
    -- ask for).
    local layoutName = (love.math.random(1, 4) == 1) and "doubles" or "wildEncounter"
    local layoutData = exportMod.exports.getLayoutData and exportMod.exports.getLayoutData(layoutName)
    local enemyCount = math.max(1, math.min(6, (layoutData and layoutData.enemyCount) or 1))
    local allyCount = math.max(1, math.min(6, (layoutData and layoutData.allyCount) or 2))

    local enemies = { capturedOpts.wild }
    for _ = 2, enemyCount do
      enemies[#enemies + 1] = Mon.new(self.game.data, capturedOpts.wild.species, capturedOpts.wild.level)
    end

    local players = {}
    for i = 1, allyCount do
      if save.party[i] then players[#players + 1] = save.party[i] end
    end

    local pushed = exportMod.exports.pushLayoutBattle(layoutName, self.game, self, {
      enemies = enemies,
      players = players,
    })
    if not pushed then
      mod.log:warn("Sample_Battle_Scene_G9: no " .. layoutName .. " preset on the export mod, "
        .. "falling back to a single wild battle")
      realStartBattle(self, capturedOpts)
    end
    return true
  end

  mod.log:info("Sample_Battle_Scene_G9: wild encounters route to "
    .. "g9-Battle-Scene (25%% chance \"doubles\", else \"wildEncounter\"); "
    .. "every 2+-mon trainer battle routes to \"doubles\"; "
    .. "wild_forms's Eternatus-as-Eternamax static routes to \"bossFight\"")
end
